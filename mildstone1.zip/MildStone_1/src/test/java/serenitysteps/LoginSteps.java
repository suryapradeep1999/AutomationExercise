package serenitysteps;

import automationexercisepages.LoginPage;
import net.thucydides.core.annotations.Step;

public class LoginSteps {

	LoginPage login;

	@Step("veryfying signuptext is visible")
	public void signUpIsVisible(String actualtext) {
		login.signUpIsVisible(actualtext);
	}

	@Step("enterying name and email")
	public void enterNameAndEmail(String name, String email) {
		login.enterNameAndEmail(name, email);
	}

	@Step("clicking on signup button")
	public void clickOnSignupButton() {
		login.clickOnSignupButton();
	}

	@Step("veryfying login to your account is visible")
	public void verifyLoginToYourAccountIsVisible(String string) {
		login.verifyLoginToYourAccountIsVisible(string);
	}

	@Step("enterying valid email and password")
	public void enterValidCredentials(String email, String password) {
		login.enterValidCredentials(email, password);
	}

	@Step("clicking on login button")
	public void clickOnLoginButton() {
		login.clickOnLoginButton();
	}

}