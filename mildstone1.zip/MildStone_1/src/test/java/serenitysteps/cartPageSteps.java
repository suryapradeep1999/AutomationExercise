package serenitysteps;

import java.util.Map;

import automationexercisepages.CartPage;
import net.thucydides.core.annotations.Step;

public class cartPageSteps {

	CartPage cart;

	@Step("validating cartpage is visible")
	public void verifyCartPageIsVisible(Map<String, String> titletext) {
		cart.verifyCartPageIsVisible(titletext);
	}

	@Step("clicking on checkout button")
	public void clickOnCheckOutButton() {
		cart.clickOnCheckOutButton();
	}
}
