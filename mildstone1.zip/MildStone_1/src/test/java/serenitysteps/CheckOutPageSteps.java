package serenitysteps;

import java.util.Map;
import automationexercisepages.CheckOutPage;
import net.thucydides.core.annotations.Step;

public class CheckOutPageSteps {

	CheckOutPage checkout;

	@Step("validating delivery  address is same as while account creation")
	public void validateDeliveryAddress(Map<String, String> logindetails) {
		checkout.validateDeliveryAddress(logindetails);
	}

	@Step("validating billling address is same as while account creation")
	public void validateBillingAddress(Map<String, String> billingdetails) {
		checkout.validateBillingAddress(billingdetails);
	}

	@Step("clicking on continue button ")
	public void clickOnDeleteButton() {
		checkout.clickOnDeleteButton();
	}
}
