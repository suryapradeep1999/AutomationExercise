package serenitysteps;

import java.util.Map;
import automationexercisepages.ProductDetailsPage;
import net.thucydides.core.annotations.Step;

public class ProductDetailsPageSteps {

	ProductDetailsPage productdetails;

	@Step("validating product details page is visible")
	public void validateProductDetailsPageTitle(Map<String, String> product) {
		productdetails.validateProductDetailsPageTitle(product);
	}

	@Step("validating product details")
	public void validateProductDetaila(Map<String, String> productinformation) {
		productdetails.validateProductDetaila(productinformation);
	}
}