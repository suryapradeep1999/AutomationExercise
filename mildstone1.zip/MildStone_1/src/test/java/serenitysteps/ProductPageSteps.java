package serenitysteps;

import automationexercisepages.ProductsPage;
import net.thucydides.core.annotations.Step;

public class ProductPageSteps {

	ProductsPage productpage;

	@Step("validating products header is visible")
	public void validateAllProductsHeader(String headervalue) {
		productpage.validateAllProductsHeader(headervalue);
	}

	@Step("validating products are visible")
	public void validateProductIsVisible() {
		productpage.validateProductIsVisible();
	}

	@Step("clicking on view product button")
	public void clickOnViewProductButton() {
		productpage.clickOnViewProductButton();
	}

}