package serenitysteps;


import automationexercisepages.DeleteMessageClass;
import net.thucydides.core.annotations.Step;

public class DeleteMessagePageSteps {

	DeleteMessageClass delete;

	@Step("verifying delete message is visible")
	public void verifyDeleteSuccessMessage() {
		delete.verifyDeleteSuccessMessage();
	}

	@Step("clicking on continue button")
	public void clickOnContinue() {
		delete.clickOnContinue();
	}
}