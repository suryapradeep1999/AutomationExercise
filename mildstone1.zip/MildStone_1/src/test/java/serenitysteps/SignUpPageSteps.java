
package serenitysteps;

import java.util.Map;

import automationexercisepages.SignUpPage;

import net.thucydides.core.annotations.Step;

public class SignUpPageSteps {

	SignUpPage signup;

	@Step("validating account information text")

	public void getAccountInformationText(String accountinformation) {

		signup.getAccountInformationText(accountinformation);

	}

	@Step("providing login details")

	public void enterAccountInformation(Map<String, String> logindetails) {

		signup.enterAccountInformation(logindetails);

	}

	@Step("validating address information text")

	public void getAddressInformationText() {

		signup.getAddressInformationText();

	}

	@Step("providing address details")

	public void addressDetails(Map<String, String> addressinformation) {

		signup.addressDetails(addressinformation);

	}

	@Step("clicking on create account")

	public void createAccount() {

		signup.createAccount();

	}

}
