package serenitysteps;

import java.util.Map;
import automationexercisepages.HomePage;
import net.thucydides.core.annotations.Step;

public class HomePageSteps {

	HomePage home;

	@Step("launching browser")
	public void launchBrowser() {
		home.open();
	}

	@Step("clicking on signup/login button")
	public void clickOnSignInButton() {
		home.clickOnSignInButton();
	}

	@Step("veryfying login to username is visible")
	public void userNameVisible(String username) {
		home.userNameVisible(username);
	}

	@Step("clicking on products button")
	public void clickOnProductsButton() {
		home.clickOnProductsButton();
	}

	@Step("validating homepage title")
	public void verifyHomePageTitle(String actualtitle) {
		home.verifyHomePageTitle(actualtitle);
	}

	@Step("clicking on navigations buttons")
	public void clickNavigationButton(Map<String, String> textinfo) {
		home.clickNavigationButton(textinfo);
	}

	@Step("scrolling down to page down")
	public void scrollDown() {
		home.scrollDown();
	}

	@Step("verifying subscription section is visible")
	public void getSubscriptionSection() {
		home.getSubscriptionSection();
	}

	@Step("clicking on arrow button")
	public void clickArrowButtion() {
		home.clickArrowButtion();
	}

	@Step("veryfying scrolled to up")
	public void verifyScrolledUp() {
		home.verifyScrolledUp();
	}

	@Step("verifying text in homepage")
	public void getAutomationText() {
		home.getAutomationText();
	}

	@Step("clicking on addtocart button")
	public void clickOnCartButton() {
		home.clickOnCartButton();
	}

	@Step("clicking on continue shopping button")
	public void clickOnContinueShopping() {
		home.clickOnContinueShopping();
	}

	@Step("clicking on cartbutton")
	public void clickCartButton() {
		home.clickCartButton();
	}
}
