package serenitysteps;

import java.util.Map;
import automationexercisepages.AccountCreatedPage;
import net.thucydides.core.annotations.Step;

public class AccountCreatedPageSteps {

	AccountCreatedPage create;

	@Step("verifying account created test is visible")
	public void verifyAccountCreated(String success, Map<String, String> messagetext) {
		create.verifyAccountCreated(success, messagetext);
	}

	@Step("clicking on continue button")
	public void clickOnContinueButton() {
		create.clickOnContinueButton();
	}

}