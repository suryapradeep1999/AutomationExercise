package testrunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

 

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features ="src/test/resources/features/automation.feature",
        glue = "stepdefinitions",
//        tags=  "@VerifyDetails",
        plugin = { "pretty", "html:target/HtmlReports" }
        )
public class AutomationRunner {

 

}