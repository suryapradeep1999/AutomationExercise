package automationexercisepages;

 

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

 

public class LoginPage extends AutomationUtiles {

 

    @FindBy(xpath = "//div[@class='signup-form']/h2")
    WebElementFacade signuptext;

 

    @FindBy(xpath = "//input[@name='name']")
    WebElementFacade entername;

 

    @FindBy(xpath = "//input[@data-qa='signup-email']")
    WebElementFacade enteremail;

 

    @FindBy(xpath = "//form[@action='/signup']/button")
    WebElementFacade signupbutton;

    @FindBy(xpath = "//div[@class='login-form']/h2")
    WebElementFacade logintoyouraccounttext;

    @FindBy(xpath = "//input[@name='email'][@data-qa='login-email']")
    WebElementFacade emailfield;

    @FindBy(xpath = "//input[@name='password'][@data-qa='login-password']")
    WebElementFacade passwordfield;

    @FindBy(xpath = "//button[@data-qa='login-button']")
    WebElementFacade loginbutton;

 

    
    public void signUpIsVisible(String actualtext) {
        getTextAndValidate(signuptext.getText(), actualtext);
    }

 

    public void enterNameAndEmail(String name, String email) {
        type(entername, name);
        type(enteremail, email);
    }

 

    public void clickOnSignupButton() {
        click(signupbutton);
        waitForMaxTime();
    }

    public void verifyLoginToYourAccountIsVisible(String string) {
        getTextAndValidate(logintoyouraccounttext.getText(),string);
    }

    public void enterValidCredentials(String email,String password) {
        click(emailfield);
        type(emailfield,email);
        click(passwordfield);
        type(passwordfield,password);
    }

    public void clickOnLoginButton() {
        click(loginbutton);
        waitForMaxTime();
    }
}
