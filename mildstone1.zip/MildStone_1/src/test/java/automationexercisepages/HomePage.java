package automationexercisepages;

 

import java.util.List;
import java.util.Map;

 

import org.junit.Assert;

 

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import utiles.AutomationUtiles;
@DefaultUrl("https://automationexercise.com")
public class HomePage extends AutomationUtiles{

 

    @FindBy(xpath = "//a[@href='/login']")
    WebElementFacade signUpLoginButton;

    @FindBy(xpath = "//a[contains(text(), 'Logged in as ')]")
    WebElementFacade myname;

    @FindBy(xpath = "//a[@href='/products']")
    WebElementFacade productsbutton;

    @FindBy(xpath ="//ol[@class='carousel-indicators']/li")
    List<WebElementFacade> navbtnlength;

    @FindBy(xpath = "//a[@href='#slider-carousel' and @class='right control-carousel hidden-xs']")
    WebElementFacade navigationbutton;

    @FindBy(xpath = "(//h2[text()='Full-Fledged practice website for Automation Engineers'])[1]")
    WebElementFacade text;

    @FindBy(xpath = "//div[@class='single-widget']/h2")
    WebElementFacade subscription;

    @FindBy(xpath = "//a[@id='scrollUp']")
    WebElementFacade scrollup;

    @FindBy(xpath = "//h2[text()='Full-Fledged practice website for Automation Engineers']")
    WebElementFacade automationengineerstext;

    @FindBy(xpath = "//a[@href='/login']")
    WebElementFacade loginbuttonis;

    @FindBy(xpath = "(//a[@data-product-id='2'][@class='btn btn-default add-to-cart'])[1]")
    WebElementFacade addtocartbutton;

 

    @FindBy(xpath = "//button[@class='btn btn-success close-modal btn-block']")
    WebElementFacade continueshoppingbutton;

 

    @FindBy(xpath = "//a[@href='/view_cart']")
    WebElementFacade cartbutton;

    public void clickOnSignInButton() {
        waitForMaxTime();
        click(signUpLoginButton);
        waitForMaxTime();
    }

    public void userNameVisible(String username) {
        String expectedname = myname.getText();
        Assert.assertTrue(expectedname.contains(username));
    }

    public void clickOnProductsButton() {
        click(productsbutton);
        waitForMaxTime();
        getDriver().navigate().refresh();
        if(productsbutton.isVisible()) {
            click(productsbutton);
        }
    }

    public void verifyHomePageTitle(String actualtitle) {
        String title = getDriver().getTitle();
        Assert.assertTrue(title.contains(actualtitle));
    }
    public void clickNavigationButton(Map<String,String> textinfo) {
        for (int i = 0; i < navbtnlength.size()-1; i++) {
            waitForSomeTime();
            click(navigationbutton);
            Assert.assertEquals(text.getText(),textinfo.get("engineerstext"));
            System.out.println(text.getText());
        }
    }

    public void scrollDown() {
        evaluateJavascript("window.scrollTo(0, document.body.scrollHeight)");
        waitForSomeTime();
        }

        public void getSubscriptionSection() {
            subscription.shouldBeVisible();
        }

        public void clickArrowButtion() {
            waitForSomeTime();
            click(scrollup);
            waitForSomeTime();
        }

        public void verifyScrolledUp() {
            loginbuttonis.shouldBeVisible();
        }

        public void getAutomationText() {
            waitForSomeTime();
            automationengineerstext.shouldBeVisible();
        }

        public void clickOnCartButton() {
            click(addtocartbutton);
            waitForSomeTime();
        }

 

        public void clickOnContinueShopping() {
            click(continueshoppingbutton);
        }

 

        public void clickCartButton() {
            click(cartbutton);
            waitForSomeTime();
        }

 

}