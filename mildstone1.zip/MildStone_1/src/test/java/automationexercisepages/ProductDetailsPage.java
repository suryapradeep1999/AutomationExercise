package automationexercisepages;

 

import java.util.Arrays;
import java.util.List;
import java.util.Map;

 

import org.junit.Assert;
import org.openqa.selenium.WebElement;

 

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

 

public class ProductDetailsPage extends AutomationUtiles {

 

    @FindBy(xpath = "//div[@class='product-information']/h2")
    WebElementFacade productname;

    @FindBy(xpath="//div[@class='product-information']/p")
    List<WebElementFacade> details;

    @FindBy(xpath = "//div[@class='product-information']/span/span")
    WebElementFacade price;

    public void validateProductDetailsPageTitle(Map<String, String> product) {
        String title = getDriver().getTitle();
        Assert.assertTrue(title.contains(product.get("productpage")));
    }

 

    public void validateProductDetaila(Map<String,String> productinformation) {
        getTextAndValidate(productname.getText(),productinformation.get("Productname"));
        getTextAndValidate(price.getText(),productinformation.get("price"));
        List<String> expectedValues = Arrays.asList(productinformation.get("categor"), productinformation.get("availability") ,
                productinformation.get("condition"),productinformation.get("brand"));
            List<WebElementFacade> elements = details;

 

                    for (int i = 0; i < expectedValues.size(); i++) {
                        String expectedValue = expectedValues.get(i);
                        WebElement element = elements.get(i);
                        String actualValue = element.getText();
                     Assert.assertEquals(expectedValue,actualValue );
                    }
    }
}
