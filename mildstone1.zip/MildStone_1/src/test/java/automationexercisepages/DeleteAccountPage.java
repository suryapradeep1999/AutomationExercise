package automationexercisepages;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

public class DeleteAccountPage extends AutomationUtiles {

	@FindBy(xpath = "//button[@class='btn btn-success close-modal btn-block']")
	WebElementFacade continueshoppingbutton;

	@FindBy(xpath = "//a[@href='/view_cart']")
	WebElementFacade cartbutton;

	@FindBy(xpath = "//a[@class='btn btn-default check_out']")
	WebElementFacade checkoutbutton;

	@FindBy(xpath = "//a[@href='/delete_account']")
	WebElementFacade deletebutton;

	@FindBy(xpath = "//h2[@class='title text-center']/b")
	WebElementFacade deletedsuccesstext;

	@FindBy(xpath = "//a[@data-qa='continue-button']")
	WebElementFacade continuebutton;

	@FindBy(xpath = "//ul[@id='address_delivery']/li")
	List<WebElementFacade> deliveryaddress;

	@FindBy(xpath = "//ul[@id='address_invoice']/li")
	List<WebElementFacade> billingaddress;
	
	@FindBy(xpath = "(//a[@data-product-id='2'][@class='btn btn-default add-to-cart'])[1]")
	WebElementFacade addtocartbutton;

	public void clickOnCartButton() {
	    click(addtocartbutton);
		waitForSomeTime();
	}

	public void clickOnContinueShopping() {
		click(continueshoppingbutton);
	}

	public void clickCartButton() {
		click(cartbutton);
		waitForSomeTime();
	}

	public void verifyCartPageIsVisible(Map<String, String> titletext) {
		String title = getDriver().getTitle();
		Assert.assertTrue(title.contains(titletext.get("titlecheck")));
	}

	public void clickOnCheckOutButton() {
		click(checkoutbutton);
		waitForMaxTime();
	}

	public void validateDeliveryAddress(Map<String, String> logindetails) {
		List<String> expectedValues = Arrays.asList(logindetails.get("deliveryaddress"), logindetails.get("name"),
				logindetails.get("company"), logindetails.get("address"), logindetails.get("secondaddress"),
				logindetails.get("stateandcity"), logindetails.get("country"), logindetails.get("mobilenumber"));
		List<WebElementFacade> elements = deliveryaddress;
		for (int i = 0; i < expectedValues.size(); i++) {
			String expectedValue = expectedValues.get(i);
			WebElement element = elements.get(i);
			String actualValue = element.getText();
			Assert.assertEquals(expectedValue, actualValue);

//              assert actualValue.equals(expectedValue) : "Assertion failed at index " + i + ". Expected: " + expectedValue + ", Actual: " + actualValue;
		}
	}

	public void validateBillingAddress(Map<String, String> billingdetails) {
		List<String> expectedValues = Arrays.asList(billingdetails.get("billingaddress"), billingdetails.get("name"),
				billingdetails.get("company"), billingdetails.get("address"), billingdetails.get("secondaddress"),
				billingdetails.get("stateandcity"), billingdetails.get("country"), billingdetails.get("mobilenumber"));
		List<WebElementFacade> elements = billingaddress;

		for (int i = 0; i < expectedValues.size(); i++) {
			String expectedValue = expectedValues.get(i);
			WebElement element = elements.get(i);
			String actualValue = element.getText();
			Assert.assertEquals(expectedValue, actualValue);
		}
	}

	public void clickOnDeleteButton() {
		click(deletebutton);
		waitForMaxTime();
	}

	public void verifyDeleteSuccessMessage() {
		Assert.assertTrue(deletedsuccesstext.isDisplayed());
	}

	public void clickOnContinue() {
		click(continuebutton);
	}

}

