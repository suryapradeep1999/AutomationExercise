package automationexercisepages;

 

import java.util.Arrays;
import java.util.List;
import java.util.Map;

 

import org.junit.Assert;
import org.openqa.selenium.WebElement;

 

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

 

public class CheckOutPage extends AutomationUtiles {

 

    @FindBy(xpath = "//ul[@id='address_delivery']/li")
    List<WebElementFacade> deliveryaddress;

 

    @FindBy(xpath = "//ul[@id='address_invoice']/li")
    List<WebElementFacade> billingaddress;

 

    @FindBy(xpath = "//a[@href='/delete_account']")
    WebElementFacade deletebutton;

 

    public void validateDeliveryAddress(Map<String, String> logindetails) {
        List<String> expectedValues = Arrays.asList(logindetails.get("deliveryaddress"), logindetails.get("name"),
                logindetails.get("company"), logindetails.get("address"), logindetails.get("secondaddress"),
                logindetails.get("stateandcity"), logindetails.get("country"), logindetails.get("mobilenumber"));
        List<WebElementFacade> elements = deliveryaddress;

 

        for (int i = 0; i < expectedValues.size(); i++) {
            String expectedValue = expectedValues.get(i);
            WebElement element = elements.get(i);
            String actualValue = element.getText();
            Assert.assertEquals(expectedValue, actualValue);
//                  assert actualValue.equals(expectedValue) : "Assertion failed at index " + i + ". Expected: " + expectedValue + ", Actual: " + actualValue;
        }
    }

 

    public void validateBillingAddress(Map<String, String> billingdetails) {
        List<String> expectedValues = Arrays.asList(billingdetails.get("billingaddress"), billingdetails.get("name"),
                billingdetails.get("company"), billingdetails.get("address"), billingdetails.get("secondaddress"),
                billingdetails.get("stateandcity"), billingdetails.get("country"), billingdetails.get("mobilenumber"));
        List<WebElementFacade> elements = billingaddress;

 

        for (int i = 0; i < expectedValues.size(); i++) {
            String expectedValue = expectedValues.get(i);
            WebElement element = elements.get(i);
            String actualValue = element.getText();
            Assert.assertEquals(expectedValue, actualValue);
        }
        ;
    }

 

    public void clickOnDeleteButton() {
        click(deletebutton);
        waitForSomeTime();
    }

 

}