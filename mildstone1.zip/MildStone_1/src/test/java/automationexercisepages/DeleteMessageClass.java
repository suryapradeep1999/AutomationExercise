package automationexercisepages;

 

import org.junit.Assert;

 

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

 

public class DeleteMessageClass extends AutomationUtiles{

 

    @FindBy(xpath = "//h2[@class='title text-center']/b")
    WebElementFacade deletedsuccesstext;

 

    @FindBy(xpath = "//a[@data-qa='continue-button']")
    WebElementFacade continuebutton;

    public void verifyDeleteSuccessMessage() {
        Assert.assertTrue(deletedsuccesstext.isDisplayed());
    }

 

    public void clickOnContinue() {
        click(continuebutton);
    }
}