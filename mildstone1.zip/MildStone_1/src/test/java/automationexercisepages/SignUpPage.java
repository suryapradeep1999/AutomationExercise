package automationexercisepages;

import java.util.Map;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

public class SignUpPage extends AutomationUtiles {

	@FindBy(xpath = "//div[@class='login-form']/h2")
	WebElementFacade accounttext;

	@FindBy(id = "id_gender1")
	WebElementFacade titleinput;

	@FindBy(id = "name")
	WebElementFacade nameinput;

	@FindBy(id = "password")
	WebElementFacade passwordinput;

	@FindBy(id = "days")
	WebElementFacade dayinput;

	@FindBy(id = "months")
	WebElementFacade monthinput;

	@FindBy(id = "years")
	WebElementFacade yearinput;

	@FindBy(id = "//div[@class='login-form']/h2")
	WebElementFacade addressinfo;

	@FindBy(id = "first_name")
	WebElementFacade firstnameinput;

	@FindBy(id = "last_name")
	WebElementFacade lastnameinput;

	@FindBy(id = "company")
	WebElementFacade companyinput;

	@FindBy(id = "address1")
	WebElementFacade addressone;

	@FindBy(id = "address2")
	WebElementFacade addresstwo;

	@FindBy(id = "country")
	WebElementFacade countryinput;

	@FindBy(id = "state")
	WebElementFacade stateinput;

	@FindBy(id = "city")
	WebElementFacade cityinput;

	@FindBy(id = "zipcode")
	WebElementFacade zipcodeinput;

	@FindBy(id = "mobile_number")
	WebElementFacade mobilenumberinput;

	@FindBy(xpath = "//button[@type='submit'][@data-qa='create-account']")
	WebElementFacade createaccountbutton;

	public void getAccountInformationText(String accountinformation) {
		getTextAndValidate(accounttext.getText(), accountinformation);
	}

	public void enterAccountInformation(Map<String, String> logindetails) {
		click(titleinput);
		type(nameinput, logindetails.get("name"));
		type(passwordinput, logindetails.get("password"));
		click(dayinput);
		click(dayinput.selectByIndex(Integer.parseInt(logindetails.get("day"))));
		click(monthinput);
		click(monthinput.selectByVisibleText(logindetails.get("month")));
		click(yearinput);
		click(yearinput.selectByVisibleText(logindetails.get("year")));
	}

	public void getAddressInformationText() {
		evaluateJavascript("window.scrollBy(0,130)");
		waitForSomeTime();
		if (addressinfo.isVisible()) {
			System.out.println("addressinformation is visible");
		} else {
			System.out.println("addressinformation is not visible");
		}
	}

	public void addressDetails(Map<String, String> addressinformation) {
		click(firstnameinput);
		type(firstnameinput, addressinformation.get("firstname"));
		click(lastnameinput);
		type(lastnameinput, addressinformation.get("lastname"));
		click(companyinput);
		type(companyinput, addressinformation.get("company"));
		click(addressone);
		type(addressone, addressinformation.get("address"));
		click(addresstwo);
		type(addresstwo, addressinformation.get("secondaddress"));
		click(countryinput);
		click(countryinput.selectByVisibleText(addressinformation.get("country")));
		click(stateinput);
		type(stateinput, addressinformation.get("state"));
		click(cityinput);
		type(cityinput, addressinformation.get("city"));
		click(zipcodeinput);
		type(zipcodeinput, addressinformation.get("zipcode"));
		click(mobilenumberinput);
		type(mobilenumberinput, addressinformation.get("mobilenumber"));
	}

	public void createAccount() {
		waitForSomeTime();
		click(createaccountbutton);
	}
}
