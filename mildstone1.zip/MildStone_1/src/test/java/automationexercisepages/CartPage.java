	package automationexercisepages;

	import java.util.Map;
	import org.junit.Assert;
	import net.serenitybdd.core.annotations.findby.FindBy;
	import net.serenitybdd.core.pages.WebElementFacade;
	import utiles.AutomationUtiles;

	public class CartPage extends AutomationUtiles {

	 

	    @FindBy(xpath = "//a[@class='btn btn-default check_out']")

	    WebElementFacade checkoutbutton;


	    public void verifyCartPageIsVisible(Map<String,String> titletext) {

	        String title = getDriver().getTitle();

	        Assert.assertTrue(title.contains(titletext.get("titlecheck")));

	    }

	 

	    public void clickOnCheckOutButton() {

	        click(checkoutbutton);

	        waitForSomeTime();

	    }

	}

