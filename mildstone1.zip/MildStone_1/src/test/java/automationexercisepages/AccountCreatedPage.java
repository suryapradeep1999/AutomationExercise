

	package automationexercisepages;

	import java.util.Map;
	import org.junit.Assert;
	import net.serenitybdd.core.annotations.findby.FindBy;
	import net.serenitybdd.core.pages.WebElementFacade;
	import utiles.AutomationUtiles;
	public class AccountCreatedPage extends AutomationUtiles{

	    @FindBy(xpath = "//section[@id='form']/div/div/div/h2")
	    WebElementFacade accountcreatedmessage;
	    @FindBy(xpath = "//p[text()='Congratulations! Your new account has been successfully created!']")
	    WebElementFacade successmessage;
        @FindBy(xpath = "//a[@class='btn btn-primary']")
        WebElementFacade continuebutton;


	    public void verifyAccountCreated(String success,Map<String,String> messagetext) {

	        waitForSomeTime();

	        String expectedsuccessmssg = accountcreatedmessage.getText();

	        Assert.assertTrue(expectedsuccessmssg.contains(success));

	        String expectedtext = successmessage.getText();

	        Assert.assertTrue(expectedtext.contains(messagetext.get("message")));

	    }

	 

	    public void clickOnContinueButton() {

	        click(continuebutton);

	        getDriver().navigate().refresh();

	        if (continuebutton.isVisible()) {

	            click(continuebutton);

	        }

	        waitForSomeTime();

	    }

	}


	


