package automationexercisepages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import utiles.AutomationUtiles;

public class ProductsPage extends AutomationUtiles {

 

    @FindBy(xpath = "//img[@src='/get_product_picture/1']")
    WebElementFacade productimage;

    @FindBy(xpath = "//h2[@class='title text-center']")
    WebElementFacade allproductspageheader;

    @FindBy(xpath = "a[@href='/product_details/2']")
    WebElementFacade viewproductbutton;
   
    public void validateAllProductsHeader(String headervalue) {
        waitForSomeTime();
        getTextAndValidate(allproductspageheader.getText(),headervalue) ;        
    }

    public void validateProductIsVisible() {
        verify(productimage.isDisplayed());
    }
    public void clickOnViewProductButton() {
        click(viewproductbutton);
        waitForSomeTime();
        getDriver().navigate().refresh();
        if(viewproductbutton.isVisible()) {
            click(viewproductbutton);
        }
    }

 

}