package stepdefinitions;

import java.util.Map;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import serenitysteps.AccountCreatedPageSteps;
import serenitysteps.CheckOutPageSteps;
import serenitysteps.DeleteMessagePageSteps;
import serenitysteps.HomePageSteps;
import serenitysteps.LoginSteps;
import serenitysteps.ProductDetailsPageSteps;
import serenitysteps.ProductPageSteps;
import serenitysteps.SignUpPageSteps;
import serenitysteps.cartPageSteps;

 

public class AutomationStepDefinitions {

 

    @Steps
    HomePageSteps homepage;
    @Steps
    LoginSteps login;
    @Steps
    SignUpPageSteps signup;
    @Steps
    AccountCreatedPageSteps accountcreated;
    @Steps
    ProductPageSteps productpage;
    @Steps
    ProductDetailsPageSteps productdetails;
    @Steps
    cartPageSteps cartpage;
    @Steps
    CheckOutPageSteps checkoutpage;
    @Steps
    DeleteMessagePageSteps deletemessagepage;

    @Given("I am on the automation exercise website")
    public void i_am_on_the_automation_exercise_website() {
        homepage.launchBrowser();
    }

    @When("I click on Sign up\\/Login button")
    public void i_click_on_sign_up_login_button() {
        homepage.clickOnSignInButton();
    }

 

    @Then("I should see {string} section")
    public void i_should_see_section(String expectedtext) {
//        automation.signUpIsVisible(expectedtext);
    }

 

    @When("I enter my {string} and {string} address")
    public void i_enter_my_and_address(String string, String string2) {
        login.enterNameAndEmail(string, string2);
    }

 

    @And("I click on Sign up button")
    public void i_click_on_Sign_up_button() {
        login.clickOnSignupButton();
    }

 

    @Then("I should see enter {string} section")
    public void i_should_see_enter_section(String accountinformation) {
        signup.getAccountInformationText(accountinformation);
    }

 

    @When("I provide my account details")
    public void i_provide_my_account_details(Map<String, String> logindetails) {
        signup.enterAccountInformation(logindetails);
    }

 

    @Then("I should see Address Information section")
    public void i_should_see_address_information_section() {
        signup.getAddressInformationText();
    }

 

    @When("I provide my address details")
    public void i_provide_my_address_details(Map<String, String> addressinformation) {
        signup.addressDetails(addressinformation);
    }

 

    @When("I click on create Account button")
    public void i_click_on_create_account_button() {
        signup.createAccount();
    }

 

    @Then("I should see {string} with success message")
    public void i_should_see_with_success_message(String success, Map<String, String> messagetext) {
        accountcreated.verifyAccountCreated(success, messagetext);
    }

 

    @When("I click on continue button")
    public void i_click_on_continue_button() {
        accountcreated.clickOnContinueButton();
    }

 

    @Then("I should see logged in as {string}")
    public void i_should_see_logged_in_as(String username) {
        homepage.userNameVisible(username);
    }

 

    @Then("I should see {string} is visible")
    public void i_should_see_is_visible(String string) {
        login.verifyLoginToYourAccountIsVisible(string);
    }

 

    @When("I enter correct {string}  and {string}")
    public void i_enter_correct_and(String email, String password) {
        login.enterValidCredentials(email, password);
    }

 

    @When("I click on login button")
    public void i_click_on_login_button() {
        login.clickOnLoginButton();
    }

 

    @When("I click on products button")
    public void i_click_on_products_button() {
        homepage.clickOnProductsButton();
    }

 

    @Then("I should be on {string} page successfully")
    public void i_should_be_on_page_successfully(String headervalue) {
        productpage.validateAllProductsHeader(headervalue);
    }

 

    @And("I should see the products list")
    public void i_should_see_the_products_list() {
        productpage.validateProductIsVisible();
    }

 

    @When("I click on view product from the product")
    public void i_click_on_view_product_from_the_product() {

 

        productpage.clickOnViewProductButton();
    }

 

    @Then("I should land on the product details page")
    public void i_should_land_on_the_product_details_page(Map<String, String> product) {
        productdetails.validateProductDetailsPageTitle(product);
    }

 

    @When("I see all the following products details")
    public void i_see_all_the_following_products_details(Map<String, String> productinformation) {
        productdetails.validateProductDetaila(productinformation);
    }

 

    @Then("I should verify {string} as title")
    public void I_should_verify_as_title(String actualtitle) {
        homepage.verifyHomePageTitle(actualtitle);
    }

 

    @When("I clicks on the navigation buttons and verifying the text")
    public void I_clicks_on_the_navigation_buttons_and_verifying_the_text(Map<String, String> textinfo) {
        homepage.clickNavigationButton(textinfo);
    }

 

    @Then("the user should be navigated to the corresponding page with correct text")
    public void the_user_should_be_navigated_to_the_corresponding_page_with_correct_text() {
        throw new io.cucumber.java.PendingException();
    }

 

    @When("I scroll down to the bottom of the page")
    public void i_scroll_down_to_the_bottom_of_the_page() {
        homepage.scrollDown();
    }

 

    @When("I verify that subscription is visible")
    public void i_verify_that_subscription_is_visible() {
        homepage.getSubscriptionSection();
    }

 

    @When("I click on the arrow at the bottom right side to move upward")
    public void i_click_on_the_arrow_at_the_bottom_right_side_to_move_upward() {
        homepage.clickArrowButtion();
    }

 

    @Then("I verify that the page is scrolled up")
    public void i_verify_that_the_page_is_scrolled_up() {
        homepage.verifyScrolledUp();
    }

 

    @Then("I verify that Full-Fledged practice website for Automation Engineers text is visible on screen")
    public void i_verify_that_full_fledged_practice_website_for_automation_engineers_text_is_visible_on_screen() {
        homepage.getAutomationText();
    }

 

    @When("I add products to the cart")
    public void i_add_products_to_the_cart() {
        homepage.clickOnCartButton();
    }

 

    @And("I click on continue shopping")
    public void i_click_on_continue_shopping() {
        homepage.clickOnContinueShopping();
    }

 

    @And("I click on the cart button")
    public void i_click_on_the_cart_button() {
        homepage.clickCartButton();
    }

 

    @Then("I should see the cart page successfully")
    public void i_should_see_the_cart_page_successfully(Map<String, String> titletext) {
        cartpage.verifyCartPageIsVisible(titletext);
    }

 

    @When("I click the proceed to checkout button")
    public void i_click_the_proceed_to_checkout_button() {
        cartpage.clickOnCheckOutButton();
    }

 

    @Then("I should see the delivery address is the same as the address filled at the time of registration")
    public void i_should_see_the_delivery_address_is_the_same_as_the_address_filled_at_the_time_of_registration(
            Map<String, String> logindetails) {
        checkoutpage.validateDeliveryAddress(logindetails);
    }

 

    @And("I should see the billing address is the same as the address filled at the time of registration")
    public void i_should_see_the_billing_address_is_the_same_as_the_address_filled_at_the_time_of_registration(
            Map<String, String> billingdetails) {

 

        checkoutpage.validateBillingAddress(billingdetails);
    }

 

    @When("I click the Delete Account button")
    public void i_click_the_delete_account_button() {
        checkoutpage.clickOnDeleteButton();
    }

 

    @Then("I should see ACCOUNT DELETED! message")
    public void i_should_see_account_deleted_message() {
        deletemessagepage.verifyDeleteSuccessMessage();
    }

 

    @Then("I click the continue button")
    public void i_click_the_continue_button() {
        deletemessagepage.clickOnContinue();
    }
}