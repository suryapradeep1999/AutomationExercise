
package utiles;

import org.junit.Assert;

import net.serenitybdd.core.pages.PageObject;

import net.serenitybdd.core.pages.WebElementFacade;

public class AutomationUtiles extends PageObject {

	public void click(WebElementFacade element) {

		element.waitUntilClickable().click();

	}

	public void type(WebElementFacade element, String value) {

		element.type(value);

	}

	public void getTextAndValidate(String expected, String actual) {

		Assert.assertEquals(expected, actual);

	}

	public void waitForSomeTime() {

		waitFor(3000).millisecond();

	}

	public void waitForMaxTime() {

		waitFor(10000).millisecond();

	}

	public void waitForTime() {

		waitFor(6000).millisecond();

	}

	public void verify(boolean value) {

		Assert.assertTrue(value);

	}

}
