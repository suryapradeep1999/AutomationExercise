package stepdefinations;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import commonutiles.GoRestUtiles;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import serenitysteps.GoRestSteps;

public class GoRestStepDef {

	@Steps
	GoRestSteps gorest;
	@Steps
	GoRestUtiles util;

	@Given("I set the base URI and path")
	public void i_set_the_base_uri_and_path() {
		util.intialSetup();
	}

	@When("I request for the list of users in second page")
	public void i_request_for_the_list_of_users_in_second_page(Map<String, String> parameter) {
		gorest.getRequest(parameter);
	}

	@Then("validate response code as {int}")
	public void validate_response_code_as(int status) {
		gorest.validateStatusCode(status);
	}

	@And("the response body should conatain")
	public void the_response_body_should_conatain(Map<String, String> details) {
//        gorest.validateresponse(details);
	}

	@Then("response time should be less than three seconds")
	public void response_time_should_be_less_than_three_seconds() {
		gorest.validateTime();
	}

	@When("I create a new user")
	public void i_create_a_new_user() throws IOException {
		gorest.postRequest();
//        gorest.get();
	}

	@When("I get the user details by user {string}")
	public void i_get_the_user_details_by_user(String id) {
		gorest.RequestById(id);
	}

	@Then("the response body should contain the {string},{string},{string},{string}")
	public <T, P, Q, R> void the_response_body_should_contain_the(T name, P string2, Q string3, R string4) {
//        gorest.validateresponse(name, string2, string3, string4);
		gorest.deSerelise();
	}

	@When("I create a new user with existing mail")
	public void i_create_a_new_user_with_existing_mail() throws IOException {
		gorest.PostRequestWithExistingMailId();
	}

	@Then("the response status code should be {int}")
	public void the_response_status_code_should_be(Integer int1) {

	}

	@Then("the response body should contain the field email with the message has already been taken")
	public void the_response_body_should_contain_the_field_email_with_the_message_has_already_been_taken(
			Map<String, String> data) {
		gorest.validateBody(data);
	}

	@When("I update the {string} details with the following data")
	public void i_update_the_details_with_the_following_data(String userid, Map<String, String> updatedetails)
			throws IOException {
		gorest.UpdateUserDetails(userid, updatedetails);
	}

	@And("the response body should contain the {string} {string}")
	public void th_response_body_should_contain_the(String gender, String male) {
		gorest.validateSingleResponseBody(gender, male);
	}

	@When("I delete the {string} which is not present")
	public void i_delete_the_which_is_not_present(String userid) {
		gorest.deleteInvalidUserId(userid);
	}

	@Then("validate response {string}")
	public void validate_response(String value) {
		gorest.valiodateResponse(value);
	}

	@When("I get the user details by user id")
	public void I_get_the_user_details_by_user_id() {
		gorest.get();
	}

}