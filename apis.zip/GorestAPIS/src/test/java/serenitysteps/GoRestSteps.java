package serenitysteps;

import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import commonutiles.GoRestUtiles;
import context.TextContext;
import static io.restassured.RestAssured.*;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.lessThan;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import static org.hamcrest.Matchers.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ValidatableResponse;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
//import pojo.ExistingDetailsDeserelization;
import pojo.GoRestDeserelization;

import pojo.GoRestSerelization;

//@RunWith(SerenityRunner.class)
public class GoRestSteps extends GoRestUtiles {
	Response response;
//    public String userid = "";
	TextContext context;
	ObjectMapper objectmapper = new ObjectMapper();

	public GoRestSteps() {
//        this.context=context;
		context = new TextContext();
	}

	@Step("fetching list of users in page one")
	public void getRequest(Map<String, String> parameter) {
		response = SerenityRest.given().log().all().relaxedHTTPSValidation()
				.queryParam(parameter.get("key"), parameter.get("value")).when().get().then().log().all().extract()
				.response();
	}

	@Step("validate time")
	public ValidatableResponse validateTime() {
		return response.then().assertThat().time(Matchers.lessThan(3000L));
	}

	@Step("validating satatus code")
	public void validateStatusCode(int statusCode) {
		Assert.assertEquals(statusCode, response.getStatusCode());
	}

	@Step("creating a post request")
	public void postRequest() throws IOException {
		String userid = "";
		GoRestSerelization gorest = new GoRestSerelization();
		gorest.setEmail(fileReader("email"));
		gorest.setName(fileReader("name"));
		gorest.setGender(fileReader("gender"));
		gorest.setStatus(fileReader("status"));
		response = requestSpec().when().body(gorest).post().then().log().all().extract().response();

		String json = response.asString();
		JsonPath js = new JsonPath(json);
		userid = js.getString("id");
		TextContext.setdata("id", userid);
		System.out.println(userid);
//        context.setId(userid);
//        response = requestSpec().when().get(context.getId()).then().log().all().extract().response();
//        Id = requestSpec().when().body(gorest).then().log().all().statusCode(200).extract()
//                .jsonPath().getInt("id");
	}

	@Step("details from tc2")
	public void get() {
		String userid = (String) TextContext.getdata("id");
//        String userid = context.getId();
//        System.out.println(userid);
		// System.out.println(context.getId());
//        response = requestSpec().when().get(context.getId()).then().log().all().extract().response();
		response = requestSpec().when().get(userid).then().log().all().extract().response();
	}

	@Step("fetching details by ID")
	public void RequestById(String id) {
		response = requestSpec().when().get(id).then().log().all().extract().response();
		String responseBody = response.asString();
		try (FileWriter fileWriter = new FileWriter("json\\response.json")) {
			fileWriter.write(responseBody);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Step("validating response")
	public <T, P, Q, R> void validateresponse(T string, P string2, Q string3, R string4) {
		GoRestDeserelization go = response.body().as(GoRestDeserelization.class);
		Assert.assertEquals(go.getName(), string);
		Assert.assertEquals(go.getEmail(), string2);
		Assert.assertEquals(go.getGender(), string3);
		Assert.assertEquals(go.getStatus(), string4);
//        response.then().assertThat().body("", equalTo(""));
	}

	@Step("")
	public void deSerelise() {
		// GoRestDeserelization go = response.body().as(GoRestDeserelization.class);
		String responsebody = "{\r\n" + "    \"id\": 2661148,\r\n" + "    \"name\": \"sudha\",\r\n"
				+ "    \"email\": \"sudha@example.com\",\r\n" + "    \"gender\": \"female\",\r\n"
				+ "    \"status\": \"active\"\r\n" + "}";
		try {
			GoRestDeserelization go = objectmapper.readValue(responsebody, GoRestDeserelization.class);
			Assert.assertEquals(go.getName(), "sudha");
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Step("creating new user by exixting mail ID")
	public void PostRequestWithExistingMailId() throws IOException {
		GoRestSerelization gorest = new GoRestSerelization();
		gorest.setEmail(fileReader("existingemail"));
		gorest.setName(fileReader("existingname"));
		gorest.setGender(fileReader("existinggender"));
		gorest.setStatus(fileReader("existingstatus"));
		response = requestSpec().when().body(gorest).post().then().log().all().assertThat()
				.body(matchesJsonSchemaInClasspath("schema.json")).extract().response();
		String json = response.asString();
		JsonPath js = new JsonPath(json);
//        id = js.getString("field");
//        System.out.println(id);
	}

	@Step("validating body")
	public void validateBody(Map<String, String> data) {
		response.then().assertThat().body("[0].field", equalTo(data.get("field"))).body("[0].message",
				equalTo(data.get("message")));
	}

	@Step("updating user details by id")
	public void UpdateUserDetails(String userid, Map<String, String> updatedetails) throws IOException {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("email", fileReader("updateemail"));
		map.put("name", fileReader("updatename"));
		response = requestSpec().when().body(map).when().put(userid).then().log().all().extract().response();
	}

	@Step("Deleting the invalid userid")
	public void deleteInvalidUserId(String userid) {
		response = requestSpec().when().delete(userid).then().log().all().extract().response();
	}

	@Step("validate delete body")
	public void valiodateResponse(String value) {
		response.then().assertThat().body("message", equalTo(value));
	}

	@Step("valiodating response body")
	public void validateSingleResponseBody(String key, String value) {
		response.then().assertThat().body(key, equalTo(value));
	}
}