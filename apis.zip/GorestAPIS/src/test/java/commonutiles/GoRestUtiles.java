package commonutiles;

 

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

 

import org.junit.Assert;

 

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

 

public class GoRestUtiles {
    RequestSpecification res;

 

    @Step("base url")
    public void intialSetup() {
        RestAssured.baseURI = "https://gorest.co.in/";
        RestAssured.basePath = "public/v2/users";
    }

 

    public RequestSpecification requestSpec() {
        res = SerenityRest.given().relaxedHTTPSValidation().log().all()
                .header("Authorization", "Bearer 6dadfe557a2ea49c3e5853f4a0e77aa95ec0fa45435cc5adc3a14c09adfbd366")
                .contentType(ContentType.JSON);
        return res;
    }

 

    public String fileReader(String input) throws IOException {
        Properties prop = new Properties();
        FileReader reader = new FileReader(
                "C:\\Users\\SU20350080\\eclipse-workspace\\gorest_APIS\\src\\test\\resources\\gorest.properties");
        prop.load(reader);
        return prop.getProperty(input);
    }
}