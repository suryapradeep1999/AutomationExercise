package context;

 

import java.util.HashMap;

 

public class TextContext {

 

//    public String id;
//    
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
    public static HashMap<String,Object> data= new HashMap<String,Object>();

 

    public static void setdata(String key, Object value)
    {
    data.put(key,value);
    }
    public static Object getdata(String key)
    {
    return data.get(key);
    }


}