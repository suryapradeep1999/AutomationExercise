package pojo;

public class BookingDates {

}
