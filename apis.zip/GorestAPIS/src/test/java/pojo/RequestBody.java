package pojo;

import java.io.FileNotFoundException;

import java.io.FileReader;

import java.io.IOException;

import java.util.ArrayList;

import java.util.HashMap;

import java.util.List;

import java.util.Map;

import java.util.Properties;

import org.junit.Test;

import org.junit.runner.RunWith;

import com.google.gson.Gson;

import io.restassured.RestAssured;

import io.restassured.http.ContentType;

import io.restassured.response.Response;

import net.serenitybdd.junit.runners.SerenityRunner;

import net.serenitybdd.rest.SerenityRest;

@RunWith(SerenityRunner.class)

public class RequestBody {

	@Test

	public void body() throws IOException {

		Properties prop = new Properties();

		FileReader reader = new FileReader(

				"C:\\Users\\SU20350080\\eclipse-workspace\\gorest_APIS\\src\\test\\resources\\gorest.properties");

		prop.load(reader);

		List<Map<String, Object>> requestbody = new ArrayList<>();

		// first object

		Map<String, Object> object1 = new HashMap<>();

		object1.put("user_id", Integer.parseInt(prop.getProperty("userid")));

		object1.put("title", prop.getProperty("title"));

		object1.put("body", prop.getProperty("body"));

		requestbody.add(object1);

		// second object

		Map<String, Object> object2 = new HashMap<>();

		object2.put("user_id", Integer.parseInt(prop.getProperty("useridtwo")));

		object2.put("title", prop.getProperty("titletwo"));

		object2.put("body", prop.getProperty("bodytwo"));

		requestbody.add(object2);

		// third object

//        Map<String, Object> object3 = new HashMap<>();

//        object3.put("id", 24957);

//        object3.put("user_id", 1706665);

//        object3.put("title", "Curto confugo currus cultura suffoco.");

//        object3.put("body", "Pauper quisquam repellat. Magni comburo trucido. Congregatio quo vicinus. Demo tabula bos. Aequitas aeger theatrum. Benigne conduco ambitus. Accipio similique balbus. Terreo causa utique. Voluptatem cognatus adnuo. Demum cohibeo depopulo. Eos valde cumque. Sumo patruus eligendi. Ut vindico numquam. Coniuratio ceno voluptas. Tribuo soleo qui.");

//        requestbody.add(object3);

		Gson gson = new Gson();

		String jsonBody = gson.toJson(requestbody);

		System.out.println(jsonBody);

//        Response response = SerenityRest.given().relaxedHTTPSValidation().log().all()

//                .header("Authorization","Bearer 6dadfe557a2ea49c3e5853f4a0e77aa95ec0fa45435cc5adc3a14c09adfbd366")

//                .contentType(ContentType.JSON).when().body(requestBody)

//                .post().then().log().all().extract().response();

		// System.out.println(requestbody);

	}

}
